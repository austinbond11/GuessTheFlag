//
//  GuessTheFlagApp.swift
//  GuessTheFlag
//
//  Created by Austin Bond on 6/5/24.
//

import SwiftUI

@main
struct GuessTheFlagApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
